(function(global){
  'use strict';

  global.Detectizr.detect();

})(this);